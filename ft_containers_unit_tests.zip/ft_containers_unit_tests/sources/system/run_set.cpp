#include "lib.hpp"

int main(int argc, char* argv[], char* env[]) {
	cout << "-----------------------------------------------------------------------------------" << endl;
	cout << "|                                       SET                                       |" << endl;
	cout << "-----------------------------------------------------------------------------------" << endl;
	printElement("Function"); printElement("Result"); printElement("ft time       std time      leaks"); cout << endl;

	runFunctionTest("../set_tests/constructor.cpp", argv, env);
	runFunctionTest("../set_tests/assign_overload.cpp", argv, env);
	runFunctionTest("../set_tests/iterators.cpp", argv, env);
	runFunctionTest("../set_tests/reverse_iterators.cpp", argv, env);
	runFunctionTest("../set_tests/comparator.cpp", argv, env);
	runFunctionTest("../set_tests/insert_value.cpp", argv, env);
	runFunctionTest("../set_tests/insert_iterators.cpp", argv, env);
	runFunctionTest("../set_tests/insert_hint.cpp", argv, env);
	runFunctionTest("../set_tests/empty.cpp", argv, env);
	runFunctionTest("../set_tests/size.cpp", argv, env);
	runFunctionTest("../set_tests/max_size.cpp", argv, env);
	runFunctionTest("../set_tests/clear.cpp", argv, env);
	runFunctionTest("../set_tests/erase_key.cpp", argv, env);
	runFunctionTest("../set_tests/erase_pos.cpp", argv, env);
	runFunctionTest("../set_tests/erase_iterators.cpp", argv, env);
	runFunctionTest("../set_tests/swap.cpp", argv, env);
	runFunctionTest("../set_tests/count.cpp", argv, env);
	runFunctionTest("../set_tests/find.cpp", argv, env);
	runFunctionTest("../set_tests/lower_bound.cpp", argv, env);
	runFunctionTest("../set_tests/upper_bound.cpp", argv, env);
	runFunctionTest("../set_tests/equal_range.cpp", argv, env);
	runFunctionTest("../set_tests/key_comp.cpp", argv, env);
	runFunctionTest("../set_tests/operator==.cpp", argv, env);
	runFunctionTest("../set_tests/operator!=.cpp", argv, env);
	runFunctionTest("../set_tests/operator<.cpp", argv, env);
	runFunctionTest("../set_tests/operator>.cpp", argv, env);
	runFunctionTest("../set_tests/operator<=.cpp", argv, env);
	runFunctionTest("../set_tests/operator>=.cpp", argv, env);

	return (0);
}